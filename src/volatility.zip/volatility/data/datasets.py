import numpy as np
import pandas as pd
from src.volatility.market.parity import EPS


def build_ssvi_dataset(
    df_open,
    min_unique_strikes_per_t=5,
    min_open_interest=500,
    max_rel_spread=0.25,
    atm_band_floor=0.015,
    atm_band_scale=0.5,
):
    """
    Build the dataset used for SSVI calibration.
    Uses call IV above forward, put IV below forward,
    and averages near ATM when both sides are liquid.
    """
    for col in ["F_parity", "D_parity"]:
        if col not in df_open.columns:
            raise ValueError(f"{col} column missing. Run parity inference first.")

    # FIX: reset index so positional indexing is safe
    df = df_open.reset_index(drop=True).copy()

    df["k"]              = np.log(df["STRIKE"].astype(float) / df["F_parity"].astype(float))
    df["total_variance"] = np.nan
    df["IV"]             = np.nan
    df["REL_SPREAD"]     = np.nan
    df["OI"]             = np.nan
    df["SIDE"]           = ""

    # FIX: collect output in plain lists then assign once — avoids df.at fragility
    tv_out   = df["total_variance"].to_numpy(dtype=float, copy = True)
    iv_out   = df["IV"].to_numpy(dtype=float, copy = True)
    rs_out   = df["REL_SPREAD"].to_numpy(dtype=float, copy = True)
    oi_out   = df["OI"].to_numpy(dtype=float, copy = True)
    side_out = df["SIDE"].to_numpy(dtype=object, copy = True)

    for i, row in df.iterrows():
        k = row.get("k",        np.nan)
        T = row.get("T",        np.nan)
        F = row.get("F_parity", np.nan)
        K = row.get("STRIKE",   np.nan)

        if not all(np.isfinite(v) and v > 0 for v in [F, K, T]) or not np.isfinite(k):
            continue

        call_iv_val = row.get("call_iv",         np.nan)
        put_iv_val  = row.get("put_iv",          np.nan)
        call_spread = row.get("call_rel_spread",  np.nan)
        put_spread  = row.get("put_rel_spread",   np.nan)
        call_oi_val = row.get("call_oi",          np.nan)
        put_oi_val  = row.get("put_oi",           np.nan)

        atm_band = max(atm_band_floor, atm_band_scale * np.sqrt(T))
        near_atm = abs(k) <= atm_band

        both_iv     = np.isfinite(call_iv_val) and np.isfinite(put_iv_val) and call_iv_val > 0 and put_iv_val > 0
        both_spread = np.isfinite(call_spread) and np.isfinite(put_spread)
        both_liquid = (
            pd.notna(call_oi_val) and pd.notna(put_oi_val)
            and call_oi_val >= min_open_interest and put_oi_val >= min_open_interest
        )

        if near_atm and both_iv and both_spread and both_liquid:
            rel_diff = abs(call_iv_val - put_iv_val) / max(0.5 * (call_iv_val + put_iv_val), EPS)
            if rel_diff <= 0.20:
                iv   = 0.5 * (call_iv_val + put_iv_val)
                rs   = min(call_spread, put_spread)
                oi   = min(call_oi_val, put_oi_val)
                side = "avg"
            else:
                if K >= F:
                    iv, rs, oi, side = call_iv_val, call_spread, call_oi_val, "call"
                else:
                    iv, rs, oi, side = put_iv_val,  put_spread,  put_oi_val,  "put"
        else:
            if K >= F:
                iv, rs, oi, side = call_iv_val, call_spread, call_oi_val, "call"
            else:
                iv, rs, oi, side = put_iv_val,  put_spread,  put_oi_val,  "put"

        if not np.isfinite(iv) or iv <= 0:
            continue

        iv_out[i]   = iv
        rs_out[i]   = rs
        oi_out[i]   = oi
        side_out[i] = side
        tv_out[i]   = iv**2 * T

    df["total_variance"] = tv_out
    df["IV"]             = iv_out
    df["REL_SPREAD"]     = rs_out
    df["OI"]             = oi_out
    df["SIDE"]           = side_out

    # Liquidity filters
    df = df[(df["OI"].isna()) | (df["OI"] >= min_open_interest)].copy()
    df = df[(df["REL_SPREAD"].isna()) | (df["REL_SPREAD"] <= max_rel_spread)].copy()
    df = df.dropna(subset=["IV", "T", "STRIKE", "F_parity", "total_variance"]).copy()
    df = df[(df["IV"] > 0) & (df["T"] > 0) & (df["STRIKE"] > 0) & (df["F_parity"] > 0)].copy()

    # Keep maturities with enough unique strikes
    counts = df.groupby("T_days")["STRIKE"].nunique()
    valid_tdays = counts[counts >= min_unique_strikes_per_t].index
    df = df[df["T_days"].isin(valid_tdays)].copy()

    return df.reset_index(drop=True)