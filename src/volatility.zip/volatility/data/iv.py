import numpy as np
from src.volatility.data.quotes import quote_from_row
from src.volatility.pricing.implied_vol import get_iv_from_forward

def compute_snapshot_iv(df_open):
    """Compute call/put IVs for each row using the parity-implied F and D of that maturity."""
    # FIX: work on a clean positional index; accumulate results in lists
    df = df_open.reset_index(drop=True).copy()
    n = len(df)

    call_iv          = np.full(n, np.nan)
    put_iv           = np.full(n, np.nan)
    call_price       = np.full(n, np.nan)
    put_price        = np.full(n, np.nan)
    call_rel_spread  = np.full(n, np.nan)
    put_rel_spread   = np.full(n, np.nan)
    call_oi          = np.full(n, np.nan)
    put_oi           = np.full(n, np.nan)
    call_method      = np.full(n, "missing", dtype=object)
    put_method       = np.full(n, "missing", dtype=object)

    # FIX: use iterrows so we get a plain dict-accessible row
    for i, row in df.iterrows():
        F = row.get("F_parity", np.nan)
        D = row.get("D_parity", np.nan)
        K = row.get("STRIKE",   np.nan)
        T = row.get("T",        np.nan)

        if not all(np.isfinite(v) for v in [F, D, K, T]):
            continue

        cprice, cspread, coi, cmethod = quote_from_row(row, "call")
        pprice, pspread, poi, pmethod = quote_from_row(row, "put")

        call_price[i]      = cprice
        put_price[i]       = pprice
        call_rel_spread[i] = cspread
        put_rel_spread[i]  = pspread
        call_method[i]     = cmethod
        put_method[i]      = pmethod
        call_oi[i]         = coi
        put_oi[i]          = poi

        if np.isfinite(cprice):
            call_iv[i] = get_iv_from_forward(cprice, F, K, T, D, "call")
        if np.isfinite(pprice):
            put_iv[i]  = get_iv_from_forward(pprice, F, K, T, D, "put")

    df["call_price"]      = call_price
    df["put_price"]       = put_price
    df["call_iv"]         = call_iv
    df["put_iv"]          = put_iv
    df["call_rel_spread"] = call_rel_spread
    df["put_rel_spread"]  = put_rel_spread
    df["call_method"]     = call_method
    df["put_method"]      = put_method
    df["call_oi"]         = call_oi
    df["put_oi"]          = put_oi

    return df
