import pandas as pd

def select_snapshot(df, snapshot_index=None, snapshot_date=None, date_col="QUOTE_DATE"):
    out = df.copy()
    out[date_col] = pd.to_datetime(out[date_col], dayfirst=True, errors="coerce")
    out = out.dropna(subset=[date_col]).copy()

    unique_dates = pd.Index(sorted(out[date_col].unique()))
    if len(unique_dates) == 0:
        raise ValueError("No valid quote dates found.")

    target = pd.Timestamp(snapshot_date if snapshot_date is not None else snapshot_index)

    exact = unique_dates[unique_dates == target]
    if len(exact) > 0:
        chosen = exact[0]
    else:
        prior = unique_dates[unique_dates <= target]
        if len(prior) == 0:
            raise ValueError("No quote date available on or before requested date.")
        chosen = prior[-1]

    snap = out[out[date_col] <= chosen].copy()
    if snap.empty:
        raise ValueError("Selected snapshot is empty.")

    snap["SNAPSHOT_DATE"] = chosen
    return snap


def build_open_options(snapshot, date_col="QUOTE_DATE"):
    """Keep only live options on the selected snapshot date."""
    df = snapshot.copy()
    for col in [date_col, "DTE", "UNDERLYING_LAST"]:
        if col not in df.columns:
            raise ValueError(f"Required column missing: {col}")

    df[date_col] = pd.to_datetime(df[date_col], dayfirst=True, errors="coerce")
    target_date = pd.Timestamp(df["SNAPSHOT_DATE"].iloc[0])

    df["EXPIRY_DATE"] = df[date_col] + pd.to_timedelta(df["DTE"], unit="D")
    df = df[(df[date_col] <= target_date) & (df["EXPIRY_DATE"] > target_date)].copy()

    df = (
        df.sort_values(date_col)
        .groupby(["STRIKE", "EXPIRY_DATE"], as_index=False)
        .last()
)

    df["T"] = (df["EXPIRY_DATE"] - target_date).dt.days / 365.0
    df["T_days"] = (df["EXPIRY_DATE"] - target_date).dt.days

    on_target = df[df[date_col] == target_date]["UNDERLYING_LAST"].dropna()
    underlying_price = float(on_target.iloc[-1]) if not on_target.empty \
                    else float(df["UNDERLYING_LAST"].dropna().iloc[-1])
    df["UNDERLYING_AT_TARGET"] = underlying_price

    df = df[df["T"] > 0].copy()
    return df.reset_index(drop=True)  # FIX: ensure clean 0-based index