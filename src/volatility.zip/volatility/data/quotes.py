import pandas as pd
import numpy as np

def side_fields(side):
    side = side.lower()
    if side == "call":
        return {"bid": "C_BID", "ask": "C_ASK", "last": "C_LAST", "oi": "C_OI"}
    elif side == "put":
        return {"bid": "P_BID", "ask": "P_ASK", "last": "P_LAST", "oi": "P_OI"}
    else:
        raise ValueError("side must be 'call' or 'put'")


def quote_from_row(row, side):
    """
    Return price, relative spread, open interest, and method.
    Prefer bid/ask mid. Fallback to last trade if no mid exists.
    """
    f = side_fields(side)

    bid  = row.get(f["bid"],  np.nan)
    ask  = row.get(f["ask"],  np.nan)
    last = row.get(f["last"], np.nan)
    oi   = row.get(f["oi"],   np.nan)

    if pd.notna(bid) and pd.notna(ask) and ask >= bid and bid > 0 and ask > 0:
        mid = 0.5 * (bid + ask)
        rel_spread = (ask - bid) / mid if mid > 0 else np.nan
        return float(mid), float(rel_spread), oi, "mid"

    if pd.notna(last) and last > 0:
        return float(last), np.nan, oi, "last"

    return np.nan, np.nan, oi, "missing"